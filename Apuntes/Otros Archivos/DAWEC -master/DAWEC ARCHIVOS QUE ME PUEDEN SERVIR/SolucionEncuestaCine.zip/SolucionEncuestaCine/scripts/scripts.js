window.onload = () => {
    document.body.addEventListener("keyup", validarLetraX, false);
    let checks = Array.from(document.getElementsByClassName("checks"));
    checks.forEach(element => {
        element.addEventListener("mouseover", marcarTextoChecks, false);
        element.addEventListener("mouseout", marcarTextoChecks, false);
    });
    document.getElementById("form").addEventListener("submit", validarFormulario, false);
};

function marcarTextoChecks() {
    let label = document.getElementById("labelOfertas");
    label.classList.toggle("sombrear");
}

function validarFormulario(event) {
    let correcto = true;

    event.preventDefault();

    let divErrores = document.getElementById("divErrores");
    divErrores.innerHTML = "";

    let nombre = document.getElementById("nombre");
    nombre.classList.remove("error");
    let email = document.getElementById("email");
    email.classList.remove("error");
    let telefono = document.getElementById("telefono");
    telefono.classList.remove("error");

    if (nombre.validity.valueMissing) {
        nombre.classList.add("error");
        let p = document.createElement("p");
        p.innerHTML = "El campo Nombre es obligatorio";
        divErrores.appendChild(p);
        correcto = false;
    }

    if (email.validity.valueMissing) {
        email.classList.add("error");
        let p = document.createElement("p");
        p.innerHTML = "El campo Email es obligatorio";
        divErrores.appendChild(p);
        correcto = false;
    } else if (email.validity.typeMismatch) {
        email.classList.add("error");
        let p = document.createElement("p");
        p.innerHTML = "El campo Email no tiene un formato correcto";
        divErrores.appendChild(p);
        correcto = false;
    }

    if (!telefono.validity.valid) {
        telefono.classList.add("error");
        let p = document.createElement("p");
        p.innerHTML = "El campo teléfono, de incluirse, debe tener 9 dígitos";
        divErrores.appendChild(p);
        correcto = false;
    }

    if (correcto) {
        document.getElementById("form").reset();
    }
}

function validarLetraX(event) {
    if ( "x" == (event.key).toLowerCase()) {
        alert(`Se ha pulsado la tecla ${event.key}`);
    }
}