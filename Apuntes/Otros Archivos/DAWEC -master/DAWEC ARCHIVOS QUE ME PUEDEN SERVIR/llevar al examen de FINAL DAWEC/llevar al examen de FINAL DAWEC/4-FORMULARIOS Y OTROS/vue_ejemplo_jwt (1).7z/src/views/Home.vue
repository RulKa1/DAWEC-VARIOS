<template>
  <div class="home">
      <h1> Página de inicio </h1>
  </div>
</template>

<script>

export default {
  name: 'Home'
}
</script>