/**
 * Declaración de la clase donde se almacenará la información de las personas que jueguen.
 * De cada jugador se almacenará el nombre y el número de números que han salido antes de que haga bingo.
 */
class Jugadas {
  constructor(jugador) {
    this.nombreJugador = jugador;
    this.numTiradas = 0;
  }
}

var numerosTablero = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var numerosBombo = [];
var jugadores = [];
var tablero = false;
var bombo = "";

/**
 * Función para generar un nuevo cartón. Si no se ha introducido un nombre de jugador no se podrá generar y
 * se avisará al usuario, mediante un alert, de que debe introducir un nombre.
 * Si se ha introducido nombre de jugador, se generarán números aleatorios entre el 1 y el 89, ambos incluidos.
 * Se comprobará que no se repitan los números de las 12 casillas.
 * Los datos del jugador se almacenarán en una nueva instancia de la clase declarada y este objeto se incluirá
 * como último elemento del array de jugadores.
 * Tras generar el cartón y almacenar los datos del usuario, se activará el bombo para que empiece a sacar números.
 */
function nuevoCarton() {
  let jugador = document.getElementById("nombreJugador").value;
  if (jugador == null || jugador == "") {
    alert("Introduzca un nombre para jugar");
  } else {
    let nuevoJugador = new Jugadas(jugador);
    jugadores.push(nuevoJugador);
    for (var i = 1; i <= 12; i++) {
      asignarNumero(i);
    }
    tablero = true;
    //Activamos el bombo para que cada 4 segundos saque un número nuevo entre 1 y 89 sin repetir
    activarBombo();
  }
}

/**
 * Función que activará el bombo.
 * Se generará un número aleatorio, entre el 1 y el 89, cada 4 segundos. Este número se mostrará en una nueva línea en el apartado
 * de bombo. Se comprobará, antes de mostrarlo, que no sea un número que haya salido ya. Si ha salido se generará otro.
 *
 */
function activarBombo() {
  numerosBombo = [];
  clearInterval(bombo);
  
  let divNumeros = document.createElement("div");
  document.getElementById("divBombo").appendChild(divNumeros);

  bombo = setInterval(() => {
    let nuevoNumero = 0;

    if (numerosBombo.length == 89) {
      alert("Bombo vacío: Fín de la partida");
      clearInterval(bombo);
      resetearJuego();
    } else {
      do {
        nuevoNumero = getSiguienteNumero();
      } while (numerosBombo.some((numero) => numero == nuevoNumero));
      numerosBombo.push(nuevoNumero);
      let numeroSacado = document.createElement("p");
      numeroSacado.innerHTML = nuevoNumero;
      divNumeros.appendChild(numeroSacado);
      numeroSacado.scrollIntoView();
      //SE incrementa en 1 el número de números que ha salido desde que empezó el juego
      let jugador = jugadores[jugadores.length - 1];
      jugador.numTiradas++;
    }
  }, 1000);
}

/**
 *
 * Función para asignar número a la casilla cuya posición llega como parametro.
 * Se comprobará que ese número no se haya asignado ya a una casilla del tablero.
 */
function asignarNumero(numCasilla) {
  let idCasilla = "casilla" + numCasilla;
  let nuevoNumero;

  do {
    nuevoNumero = getSiguienteNumero();
  } while (numerosTablero.some((numero) => numero === nuevoNumero));

  numerosTablero[numCasilla - 1] = nuevoNumero;
  document.getElementById(idCasilla).innerHTML = nuevoNumero;
  document.getElementById(idCasilla).className = "";
}

function getSiguienteNumero() {
  return Math.floor(Math.random() * 89 + 1);
}

/**
 * Función para asignar color de fondo a las casillas e los números que ya hayan salido del bombo.
 */
function cambiarColor(casilla) {
  if (tablero) {
    casilla.className = "casillaSeleccionada";
    comprobarBingo();
  }
}

/**
 * Función para comprobar si se ha cantado bingo.
 * Se llamará a esta función cada vez que se "tache" un número del cartón.
 */
function comprobarBingo() {
  for (var i = 1; i <= 12; i++) {
    var casillaAComprobar = "casilla" + i;
    if (
      document.getElementById(casillaAComprobar).className !=
      "casillaSeleccionada"
    ) {
      return false;
    }
  }

  //Si el jugador ha hecho bingo se muestra la palabra BINGO seguida del número de números
  //que han tenido que salir antes de que llegue a Bingo
  alert("BINGO!! " + jugadores[jugadores.length - 1].numTiradas);
  resetearJuego();
}

/**
 * Función para resetear el juego cada vez que se cante bingo.
 * Se inicializarán todas las variables salvo el array de jugadores, que se ha de mantener para ir almacenando
 * la información de cada jugador.
 */
function resetearJuego() {
  console.log("Numeros totales bombo" + numerosBombo);
  //Reseteamos las variables de partida menos los datos de los jugadores anteriores
  numerosTablero = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  numerosBombo = [];
  tablero = false;
  clearInterval(bombo);
  document.getElementById("divBombo").innerHTML = "Números jugados:";
  for (var i = 1; i <= 12; i++) {
    document.getElementById("casilla" + i).innerHTML = "";
    document.getElementById("casilla" + i).className = "";
  }
  document.getElementById("nombreJugador").value = "";
}
